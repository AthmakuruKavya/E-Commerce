import React from 'react'
import './App.css'
import { Routes, Route} from 'react-router-dom'
import LandingPage from './stores/pages/LandingPage'
import MobilePage from './stores/pages/MobilePage'
import ComputerPage from './stores/pages/ComputerPage'
import WatchPage from './stores/pages/WatchPage'
import MenPage from './stores/pages/MenPage'
import WomenPage from './stores/pages/WomenPage'
import FurniturePage from './stores/pages/FurniturePage'
import KitchenPage from './stores/pages/KitchenPage'
import FridgePage from './stores/pages/FridgePage'
import SpeakerPage from './stores/pages/SpeakerPage'
import TvPage from './stores/pages/TvPage'
import AcPage from './stores/pages/AcPage'
import MobileSingles from './singles/MobileSingles'
import ComputerSingles from './singles/ComputerSingles'
import WatchesSingles from './singles/WatchesSingles'
import MenSingles from './singles/MenSingles'
import WomenSingles from './singles/WomenSingles'
import FurnitureSingles from './singles/FurnitureSingles'
import KitchenSingles from './singles/KitchenSingles'
import FridgeSingles from './singles/FridgeSingles'
import SpeakerSingles from './singles/SpeakerSingles'
import AcSingles from './singles/AcSingles'
import TvSingles from './singles/TvSingles'
import UserCart from './stores/pages/UserCart'

const App = () => {
  return (
    <div>
        <Routes>

          <Route path='/' element={<LandingPage/>} />
          <Route path='/mobiles' element={<MobilePage/>} />   
          <Route path='/computers' element={<ComputerPage/>} />  
          <Route path='/watches' element={<WatchPage/>} />
          <Route path='/mens' element={<MenPage/>} /> 
          <Route path='/woman' element={<WomenPage/>} />
          <Route path='/furniture' element={<FurniturePage/>} />
          <Route path='/kitchen' element={<KitchenPage/>} />
          <Route path='/fridge' element={<FridgePage/>} />
          <Route path='/speaker' element={<SpeakerPage/>} />
          <Route path='/tv' element={<TvPage/>} />
          <Route path='/ac' element={<AcPage/>} />

          <Route path='/mobiles/:id' element={<MobileSingles/>} />
          <Route path='/computers/:id' element={<ComputerSingles/>} />
          <Route path='/watches/:id' element={<WatchesSingles/>} />
          <Route path='/men/:id' element={<MenSingles/>} />
          <Route path='/women/:id' element={<WomenSingles/>} />
          <Route path='/furniture/:id' element={<FurnitureSingles/>} />
          <Route path='/kitchen/:id' element={<KitchenSingles/>} />
          <Route path='/fridge/:id' element={<FridgeSingles/>} />
          <Route path='/speaker/:id' element={<SpeakerSingles/>} />
          <Route path='/ac/:id' element={<AcSingles/>} />
          <Route path='/tv/:id' element={<TvSingles/>} />

          <Route path='/cart' element={<UserCart/>} />

        </Routes>
    </div>
  )
}

export default App