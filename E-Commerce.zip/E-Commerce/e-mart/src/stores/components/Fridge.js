import React from 'react'
import { fridgeData } from '../data/fridge'
import { Link } from 'react-router-dom'

const Fridge = () => {
    const firstfiveimages= fridgeData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Fridges</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/fridge'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Fridge