import React from 'react'
import { Link } from 'react-router-dom'
import { useCart } from '../cart/CartContext'

const Navbar = () => {
    const {cartItem} = useCart()
  return (
    <>
        <div className='navbar-section'>
            <div className='navsection'>
                <Link to='/' className='custom-link'>
                    <div className='title'>
                        <h2>E-Mart</h2>
                    </div>
                </Link>
                <div className='search'>
                    <input type='text' placeholder='Search...' />
                </div>
                <div className='user'>
                    <div className='user-detail'>
                        SignIn/SignUp
                    </div>
                    <Link to='/cart' className='custom-link'>
                        <div className='cart'>
                            Cart
                            <span>{cartItem.length}</span>
                        </div>
                    </Link>
                </div>
            </div>
            <div className='subMenu'>
                <ul>
                    <Link to='/mobiles' className='custom-link'>
                        <li>Mobiles</li>
                    </Link>
                    <Link to='/computers' className='custom-link'>
                        <li>Computers</li>
                    </Link>
                    <Link to='/watches' className='custom-link'>
                        <li>Watches</li>
                    </Link>
                    <Link to='/mens' className='custom-link'>
                        <li>Men Fashion</li>
                    </Link>
                    <Link to='/woman' className='custom-link'>
                        <li>Women Dressing</li>    
                    </Link>
                    <Link to='/furniture' className='custom-link'>
                        <li>Furniture</li>    
                    </Link>
                    <Link to='/kitchen' className='custom-link'>
                        <li>Kitchen</li>    
                    </Link>
                    <Link to='/fridge' className='custom-link'>
                        <li>Fridges</li>
                    </Link>
                    <Link to='/speaker' className='custom-link'>
                        <li>Speakers</li>
                    </Link>
                    <Link to='/tv' className='custom-link'>
                        <li>Televisions</li>
                    </Link>
                    <Link to='/ac' className='custom-link'>
                        <li>Ac</li>
                    </Link>
                    {/* <Link to='/books' className='custom-link'>
                        <li>Books</li>    
                    </Link> */}
                </ul>
            </div>
        </div>
    </>

  )
}

export default Navbar