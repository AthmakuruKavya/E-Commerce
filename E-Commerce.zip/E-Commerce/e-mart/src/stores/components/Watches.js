import React from 'react'
import { watchData } from '../data/watch'
import { Link } from 'react-router-dom'

const Watches = () => {
    const firstfiveimages= watchData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Watches</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/watches'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Watches