import React from 'react'
import Mobiles from './Mobiles'
import Computers from './Computers'
import Watches from './Watches'
import MensWear from './MensWear'
import Womens from './Womens'
import Furnitures from './Furnitures'
import Kitchen from './Kitchen'
import Fridge from './Fridge'
import Speakers from './Speakers'
import Tvs from './Tvs'
import Ac from './Ac'


const Products = () => {
  return (
    <div>
      <Mobiles/>
      <Computers/>
      <Watches/>
      <MensWear/>
      <Womens/>
      <Furnitures/>
      <Kitchen/>
      <Fridge/>
      <Speakers/>
      <Tvs/>
      <Ac/>
    </div>
  )
}

export default Products