import React from 'react'
import { tvData } from '../data/tv'
import { Link } from 'react-router-dom'

const Tvs = () => {
    const firstfiveimages= tvData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Televisions</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/tv'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Tvs