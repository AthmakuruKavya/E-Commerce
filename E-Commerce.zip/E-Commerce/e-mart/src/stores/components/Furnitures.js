import React from 'react'
import { furnitureData } from '../data/furniture'
import { Link } from 'react-router-dom'

const Furnitures = () => {
    const firstfiveimages= furnitureData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Furnitures</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/furniture'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Furnitures