import React from 'react'
import { womanData } from '../data/woman'
import { Link } from 'react-router-dom'

const Womens = () => {
    const firstfiveimages= womanData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Women Wear</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/woman'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Womens