import React from 'react'
import { acData } from '../data/ac'
import { Link } from 'react-router-dom'

const Ac = () => {
    const firstfiveimages= acData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Air Conditioners</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/ac'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
        </div>
    </>
  )
}

export default Ac