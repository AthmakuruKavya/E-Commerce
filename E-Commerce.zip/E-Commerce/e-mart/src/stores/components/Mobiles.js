import React from 'react'
import { mobileData } from '../data/mobiles'
import { Link } from 'react-router-dom'

const Mobiles = () => {
    const firstfiveimages= mobileData.slice(0,5)
  return (
    <>
        <div className='protitle'>
            <h2>Mobiles</h2>
        </div>
        <div className='prosection'>
        {
            firstfiveimages.map( (item) => {
                return(
                    <Link to='/mobiles'>
                        <div className='imgBox'>
                            <img  className='proimage' src={item.image} alt=''></img>
                        </div>
                    </Link>
                )
            })
        }
    </div>
    </>
  )
}

export default Mobiles