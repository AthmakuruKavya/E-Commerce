import React, { useState } from 'react'
import { computerData } from '../data/computers'
import Navbar from '../components/Navbar'
import { Link } from 'react-router-dom'

const ComputerPage = () => {
    const [selectedProduct, setSelectedProduct] = useState([])
    
        const companyHandler = (thing) => {
            if(selectedProduct.includes(thing)){
                setSelectedProduct(selectedProduct.filter(item => item !== thing))
            }else{
                setSelectedProduct([...selectedProduct, thing])
            }
        }
    
        const filterProduct = selectedProduct.length === 0 ?
            computerData : computerData.filter((mobile) => selectedProduct.includes(mobile.company))
  return (
    <>
        <Navbar/>
        <div className='fullPage'>
            <div className='pro-selected '>
                            {
                                computerData.map( (phone) => {
                                    return(
                                        <div className='pro-input'>
                                            <label>
                                                <input type='checkbox'
                                                checked= {selectedProduct.includes(phone.company)}
                                                onChange={ () => companyHandler(phone.company)}
                                                />
                                                {phone.company}
                                            </label>
                                        </div>
                                    )
                                })
                            }
                        </div>
            <div className='pageSection'>
                {
                    filterProduct.map( (item) => {
                        return(
                            <div className='proStyle'>
                                <Link to={`/computers/${item.id}`}>
                                    <div className='pageImg'>
                                        <img src={item.image} alt=''/> 
                                    </div>
                                </Link>
                                <div className='proModel'>
                                    {item.company} {item.model}
                                </div> 
                            </div>
                            
                        )

                    })
                }
            </div>
        </div>
    </>
  )
}

export default ComputerPage