import React, { useState } from 'react'
import { kitchenData } from '../data/kitchen'
import Navbar from '../components/Navbar'
import { Link } from 'react-router-dom'

const KitchenPage = () => {
    const [selectedProduct, setSelectedProduct] = useState([])

    const companyHandler = (thing) => {
        if(selectedProduct.includes(thing)){
            setSelectedProduct(selectedProduct.filter(item => item !== thing))
        }else{
            setSelectedProduct([...selectedProduct, thing])
        }
    }

    const filterProduct = selectedProduct.length === 0 ?
        kitchenData : kitchenData.filter((mobile) => selectedProduct.includes(mobile.brand))
  return (
    <>
        <Navbar/>
        <div className='fullPage'>
            <div className='pro-selected '>
                {
                kitchenData.map( (phone) => {
                        return(
                            <div className='pro-input'>
                                <label>
                                    <input type='checkbox'
                                    checked= {selectedProduct.includes(phone.brand)}
                                    onChange={ () => companyHandler(phone.brand)}
                                    />
                                    {phone.brand}
                                </label>
                            </div>
                        )
                    })
                    }                            
            </div>
            <div className='pageSection'>
                {
                    filterProduct.map( (item) => {
                        return(
                            <div className='proStyle'>
                                <Link to={`/kitchen/${item.id}`}>
                                    <div className='pageImg'>
                                        <img src={item.image} alt=''/> 
                                    </div>
                                </Link>
                                <div className='proModel'>
                                    {item.brand} {item.type}
                                </div> 
                            </div>
                            
                        )

                    })
                }
            </div>
        </div>
    </>
  )
}

export default KitchenPage