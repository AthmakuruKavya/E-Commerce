import React from 'react'
import { useCart } from '../cart/CartContext'
import Navbar from '../components/Navbar'

const UserCart = () => {

    const {cartItem, addToCart,  removeCartItem} = useCart()

  return (
    <>
        <Navbar/>
        <div>
            <h2 className='y-cart'>Your Cart</h2>
            {
                cartItem.length === 0 ?
                (<p className='empty'>Your Cart is Empty</p>):
                <div>
                    {
                        cartItem.map( (item) => {
                            return(
                                <div className='cart-section'>
                                    <div className='cart-img'>
                                        <img src={item.image} alt='' />
                                    </div>
                                    <div className='cart-details'>
                                        <h3>{item.product}</h3>
                                        <h2>{item.price}</h2>
                                        <h3>{item.company} {item.brand} {item.model}</h3>
                                    </div>
                                    <button className='removeBtn' onClick={ () => removeCartItem(item)}>Remove</button>
    
                                </div>
                            )
                        })
                    }
                </div>
            }
        </div>
    </>
  )
}

export default UserCart